# --coding:utf-8--
import re
from dataclasses import field
from enum import Enum
from functools import cached_property
from typing import Any, Dict, List, Optional, Union, Set
from pydantic import BaseModel, Field, ConfigDict, field_validator


def normalize_python_name(name: str, to_pascal_case: bool = True) -> str:
    """将名称规范化为合法的Python标识符
    
    Args:
        name: 要规范化的名称
        to_pascal_case: 是否转换为大驼峰形式（PascalCase），适用于类名
        
    Returns:
        规范化后的名称
    """
    # 如果名称以下划线开头，去掉开头的下划线
    if name.startswith('_'):
        name = name[1:]
        
    # 替换非法字符
    normalized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    # 确保不以数字开头
    if normalized and normalized[0].isdigit():
        normalized = '_' + normalized
        
    # 转换为大驼峰形式
    if to_pascal_case:
        # 处理下划线分隔的情况
        if '_' in normalized:
            # 将连续的下划线替换为单个下划线
            normalized = re.sub(r'_+', '_', normalized)
            # 分割字符串，保留每个部分原有的大小写形式，但确保首字母大写
            parts = normalized.split('_')
            normalized = ''.join(
                (part[0].upper() + part[1:]) if part else ''
                for part in parts
            )
        else:
            # 处理已有驼峰形式的情况，确保首字母大写
            normalized = normalized[0].upper() + normalized[1:] if normalized else ''
        
    return normalized


class Reference(BaseModel):
    # name: str
    ref: str = Field(..., alias='$ref')  # 存储引用路径，例如 "#/components/schemas/Pet"

    class Config:
        populate_by_name = True


class Import(BaseModel):
    """导入语句"""
    from_: Optional[str]
    import_: str
    alias: Optional[str] = None
    model_config = ConfigDict(
        frozen=True,
        extra='forbid'
    )


class DataType(BaseModel):
    type: str
    reference: Optional[Reference] = None
    data_types: Optional[List['DataType']] = None
    is_list: bool = False
    is_dict: bool = False
    is_optional: bool = False
    is_custom_type: bool = False
    is_forward_ref: bool = False
    is_inline: bool = False
    imports: Set[Import] = Field(default_factory=set)
    fields: List["DataModelField"] = Field(default_factory=list)

    @field_validator('type')
    @classmethod
    def normalize_type_name(cls, type_name: str, info) -> str:
        if getattr(info.data, 'is_custom_type', False):
            return normalize_python_name(type_name)
        return type_name

    @field_validator('imports')
    @classmethod
    def normalize_import_names(cls, imports: Set[Import], info) -> Set[Import]:
        # 只有自定义类型需要规范化导入名称
        if getattr(info.data, 'is_custom_type', False):
            new_imports = set()
            for imp in imports:
                if imp.from_ == '.models':
                    # 规范化导入的模型名称
                    new_imports.add(Import(
                        from_=imp.from_,
                        import_=normalize_python_name(imp.import_),
                        alias=imp.alias
                    ))
                else:
                    new_imports.add(imp)
            return new_imports
        return imports

    @property
    def type_hint(self) -> str:
        """生成类型提示"""
        type_str = self.type
        
        # 确保自定义类型使用规范化名称
        if self.is_custom_type and type_str:
            type_str = normalize_python_name(type_str)
            
        if self.is_list:
            # 确保列表元素类型也被规范化
            if self.data_types and self.data_types[0].is_custom_type:
                inner_type = self.data_types[0].type_hint  # 递归调用type_hint确保内部类型也被规范化
            else:
                inner_type = self.data_types[0].type_hint if self.data_types else 'Any'
            type_str = f'List[{inner_type}]'
        elif self.is_dict:
            key_type = self.data_types[0].type_hint if self.data_types else 'str'
            value_type = self.data_types[1].type_hint if len(self.data_types) > 1 else 'Any'
            type_str = f'Dict[{key_type}, {value_type}]'
        elif self.is_optional:
            type_str = f'Optional[{type_str}]'
        
        return type_str


class DataModelField(BaseModel):
    """模型字段"""
    name: str
    data_type: DataType
    required: bool = True
    default: Optional[Any] = None
    description: Optional[str] = None
    alias: Optional[str] = None


DataType.model_rebuild()
DataModelField.model_rebuild()


class DataModel(BaseModel):
    """数据模型"""
    name: str
    fields: List[DataModelField]
    tags: List[str] = Field(default_factory=list)
    is_enum: bool = False
    is_inline: bool = False  # 是否内联在接口类中
    reference: Optional[Reference] = None
    description: Optional[str] = None
    base_class: str = "attrs.define"
    imports: Set[Import] = Field(default_factory=set)
    required: List[DataModelField] = Field(default_factory=set)
    is_forward_ref: bool = False

    @field_validator('name')
    @classmethod
    def normalize_model_name(cls, name: str) -> str:
        return normalize_python_name(name)


class ParameterLocation(str, Enum):
    query = 'query'
    path = 'path'
    header = 'header'
    cookie = 'cookie'


class MediaTypeEnum(Enum):
    """常用的 Media Type 枚举"""
    JSON = "application/json"
    XML = "application/xml"
    FORM = "application/x-www-form-urlencoded"
    MULTIPART = "multipart/form-data"
    TEXT = "text/plain"
    HTML = "text/html"
    BINARY = "application/octet-stream"
    PDF = "application/pdf"
    ANY = "*/*"


class Example(BaseModel):
    summary: Optional[str] = None
    description: Optional[str] = None
    value: Any = None
    externalValue: Optional[str] = None


class MediaType(BaseModel):
    schema_: Union[Reference, "JsonSchemaObject", None] = Field(
        None, alias='schema'
    )
    example: Any = None
    examples: Union[str, Reference, Example, None] = None


class Parameter(BaseModel):
    name: Optional[str] = None
    in_: Optional[ParameterLocation] = Field(None, alias='in')
    description: Optional[str] = None
    required: bool = False
    deprecated: bool = False
    schema_: Optional["JsonSchemaObject"] = Field(None, alias='schema')
    example: Any = None
    examples: Union[str, Reference, Example, None] = None
    content: Dict[str, MediaType] = Field(default_factory=dict)


class RequestBody(BaseModel):
    content: Dict[str, MediaType] = None
    required: bool = False
    description: Optional[str] = None


class Response(BaseModel):
    content: Dict[str, MediaType] = None
    description: Optional[str] = None


class Operation(BaseModel):
    tags: List[str] = field(default_factory=list)
    summary: Optional[str] = None
    description: Optional[str] = None
    operationId: Optional[str] = None
    parameters: List[Union[Reference, Parameter]] = field(default_factory=list)
    requestBody: Union[Reference, RequestBody, None] = None
    responses: Dict[Union[str, int], Union[Reference, Response]] = field(default_factory=dict)
    deprecated: bool = False


class Endpoint(BaseModel):
    class_name: str
    path: str
    method: str
    endpoint_id: str = field(default=None)
    tags: List[str] = field(default_factory=list)
    description: Optional[str] = None
    path_parameters: List[DataModelField] = field(default_factory=list)
    query_parameters: List[DataModelField] = field(default_factory=list)
    header_parameters: List[DataModelField] = field(default_factory=list)
    request_body: Optional[DataModel] = None
    response: Optional[DataModel] = None
    imports: Set[Import] = field(default_factory=set)


class APIGroup(BaseModel):
    tag: str
    endpoints: List[Endpoint] = field(default_factory=list)
    models: Dict[str, DataModel] = field(default_factory=dict)
    endpoint_names: Set[str] = field(default_factory=set)

    def collect_models(self, model_registry):
        """从全局注册表中收集属于当前 Tag 的模型"""
        # todo: 有的模型可能会同时出现在多个tag中，这种其实可以提取出来放到common中，看怎么处理
        for model in model_registry.models.values():
            if self.tag in model.tags:
                self.models[model.name] = model

    def add_endpoint(self, endpoint: Endpoint):
        name = endpoint.class_name
        if name in self.endpoint_names:
            i = 1
            while f"{name}_{i}" in self.endpoint_names:
                i += 1
            name = f"{name}_{i}"
            endpoint.class_name = name
        self.endpoint_names.add(name)
        self.endpoints.append(endpoint)


class JsonSchemaObject(BaseModel):
    """ 仅用于解析 OpenAPI Schema 的中间模型，与最终生成的 attrs 模型无关 """

    type: Union[str, List[str], None] = None
    format: Optional[str] = None
    items: Union['JsonSchemaObject', List['JsonSchemaObject'], None] = None
    properties: Optional[Dict[str, 'JsonSchemaObject']] = None
    required: List[str] = field(default_factory=list)
    enum: List[Any] = field(default_factory=list)
    ref: Optional[str] = Field(None, alias='$ref')  # 解析 $ref 时使用
    nullable: bool = False
    title: str = None

    minimum: Optional[Union[int, float]] = None
    maximum: Optional[Union[int, float]] = None
    min_length: Optional[int] = Field(None, alias='minLength')
    max_length: Optional[int] = Field(None, alias='maxLength')

    oneOf: List["JsonSchemaObject"] = field(default_factory=list)
    anyOf: List["JsonSchemaObject"] = field(default_factory=list)
    allOf: List["JsonSchemaObject"] = field(default_factory=list)

    description: Optional[str] = None
    default: Any = None

    @cached_property
    def is_array(self) -> bool:
        return self.items is not None or self.type == 'array'

    @cached_property
    def is_object(self) -> bool:
        return (
                self.properties is not None
                or self.type == 'object'
                and not self.allOf
                and not self.oneOf
                and not self.anyOf
                and not self.ref
        )


JsonSchemaObject.model_rebuild()

if __name__ == '__main__':
    Reference(ref="#/components/schemas/EnvModel")
