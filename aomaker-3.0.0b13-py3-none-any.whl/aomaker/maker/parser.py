# --coding:utf-8--
import json
from collections import defaultdict
from typing import Dict, List, Optional, Union

from rich.console import Console

from aomaker.maker.models import DataModelField, Operation, Reference, Response, RequestBody, Import, MediaType, \
    MediaTypeEnum, Parameter, APIGroup, Endpoint, DataType, JsonSchemaObject, DataModel
from aomaker.log import logger
from aomaker.maker.jsonschema import JsonSchemaParser
from aomaker.maker.config import OpenAPIConfig
from aomaker.maker.compat import SwaggerAdapter
from aomaker.maker.models import normalize_python_name

SUPPORTED_CONTENT_TYPES = [
    MediaTypeEnum.JSON.value,
    MediaTypeEnum.ANY.value,
    MediaTypeEnum.FORM.value,
    MediaTypeEnum.MULTIPART.value,
    MediaTypeEnum.BINARY.value,
    MediaTypeEnum.XML.value,
    MediaTypeEnum.TEXT.value,
    MediaTypeEnum.HTML.value
]


class OpenAPIParser(JsonSchemaParser):
    def __init__(self, openapi_data: Dict, config: OpenAPIConfig = None, console: Console = None):
        if SwaggerAdapter.is_swagger(openapi_data):
            openapi_data =  SwaggerAdapter.adapt(openapi_data)
        super().__init__(openapi_data.get("components", {}).get("schemas", {}))
        self.openapi_data = openapi_data
        self.api_groups: Dict[str, APIGroup] = {}
        self.config: OpenAPIConfig = config or OpenAPIConfig()
        self.console = console or Console()

    def _register_component_schemas(self):
        """预注册所有组件模式"""
        for name, schema in self.resolver.schema_objects.items():
            self.parse_schema(schema, name)

    def parse(self) -> List[APIGroup]:
        """主解析流程"""
        paths = self.openapi_data.get('paths', {})
        total_paths = len(paths)
        for idx, (path, path_item) in enumerate(paths.items(), 1):
            for method, op_data in path_item.items():
                if method.lower() not in {'get', 'post', 'put', 'delete', 'patch'}:
                    continue
                if self.console:
                    self.console.log(
                        f"[primary]✅ [bold]已解析:[/] "
                        f"[accent]{method.upper()}[/] "
                        f"[muted]on[/] "
                        f"[accent]{path}[/] "
                        f"[muted]({idx}/{total_paths})[/]"
                    )
                operation = Operation.model_validate(op_data)
                self.current_tags = operation.tags
                endpoint = self.parse_endpoint(path, method, operation)

                for tag in operation.tags or ['default']:
                    if tag not in self.api_groups:
                        self.api_groups[tag] = APIGroup(tag=tag)
                    self.api_groups[tag].add_endpoint(endpoint)
                    self.api_groups[tag].collect_models(self.model_registry)
        # self._organize_models()
        return list(self.api_groups.values())

    def parse_endpoint(self, path: str, method: str, operation: Operation) -> Endpoint:
        class_name = self.config.class_name_strategy(path, method, operation)
        endpoint = Endpoint(
            class_name=class_name,
            endpoint_id=operation.operationId or f"{path}_{method}",
            path=path,
            method=method,
            tags=operation.tags,
            description=operation.description
        )

        # 解析参数
        parameters = self.parse_parameters(operation.parameters)
        endpoint.path_parameters = parameters['path']
        endpoint.query_parameters = parameters['query']
        endpoint.header_parameters = parameters['header']
        for field_ in endpoint.path_parameters + endpoint.query_parameters:
            for imp in field_.data_type.imports:
                endpoint.imports.add(imp)
            # 确保参数类型的名称规范化
            if field_.data_type.is_custom_type and field_.data_type.type:
                field_.data_type.type = normalize_python_name(field_.data_type.type)
                
        # 解析请求体
        if operation.requestBody:
            request_body_datatype = self.parse_request_body(operation.requestBody, endpoint.class_name)
            if request_body_datatype is not None:
                if request_body_datatype.reference:
                    endpoint.request_body = self.model_registry.get(request_body_datatype.type)
                elif request_body_datatype.is_inline is True:
                    endpoint.request_body = DataModel(
                        name="RequestBody",
                        fields=request_body_datatype.fields,
                        imports=request_body_datatype.imports
                    )
                else:
                    endpoint.request_body = request_body_datatype

                if endpoint.request_body is not None:
                    for imp in endpoint.request_body.imports:
                        endpoint.imports.add(imp)
                    # 规范化请求体中所有字段的类型名称
                    if hasattr(endpoint.request_body, 'fields'):
                        for field_ in endpoint.request_body.fields:
                            if field_.data_type.is_custom_type and field_.data_type.type:
                                field_.data_type.type = normalize_python_name(field_.data_type.type)

        # 解析响应
        if operation.responses:
            response_type = self.parse_response(operation.responses, endpoint.class_name)
            endpoint.response = self.model_registry.get(response_type.type)
            response_import = Import(from_='.models', import_=response_type.type)
            endpoint.imports.add(response_import)
            # 规范化响应中所有字段的类型名称
            if endpoint.response and hasattr(endpoint.response, 'fields'):
                for field_ in endpoint.response.fields:
                    if field_.data_type.is_custom_type and field_.data_type.type:
                        field_.data_type.type = normalize_python_name(field_.data_type.type)
            
        endpoint.imports.add(Import(from_='typing', import_='Optional'))
        return endpoint

    def parse_parameters(self, parameters: List[Union[Reference, Parameter]]) -> Dict[str, List[DataModelField]]:
        parsed = defaultdict(list)
        for param in parameters:
            param_obj = self._resolve_parameter(param)
            location = param_obj.in_.value
            if param_obj.schema_:
                data_type = self._parse_parameter_schema(param_obj.name, param_obj.schema_)
                default = param_obj.schema_.default
                description = param_obj.schema_.description
            elif param_obj.content:
                data_type = self._parse_content_schema(param_obj.name, param_obj.content)
                default = param_obj.content.get(MediaTypeEnum.JSON.value).schema_.default
                description = param_obj.content.get(MediaTypeEnum.JSON.value).description
            else:
                raise ValueError(f"参数未定义 schema_obj 或 content: {param_obj.name}")

            field_ = DataModelField(
                name=param_obj.name,
                data_type=data_type,
                required=param_obj.required,
                default=default,
                description=description,
            )
            parsed[location].append(field_)

        # 排序：必填参数在前
        for loc in parsed:
            parsed[loc].sort(key=lambda x: not x.required)
        return parsed

    def parse_request_body(
            self,
            request_body: RequestBody,
            endpoint_name: str
    ) -> Optional[DataType]:
        """解析请求体，返回类型并触发模型生成"""
        for content_type in SUPPORTED_CONTENT_TYPES:
            # 1. 获取JSON Schema
            content = request_body.content.get(content_type)
            if not content or not content.schema_:
                continue

            # 2. 生成上下文名称
            context_name = f"{endpoint_name}RequestBody"
            # 3. 解析类型
            body_type = self.parse_schema(content.schema_, context_name)

            # 4. 如果是对象类型，确保模型已生成
            if body_type.is_custom_type and body_type.type not in self.model_registry.models:
                raise ValueError(f"未注册的自定义类型: {body_type.type}")

            return body_type

    def parse_response(
            self,
            responses: Dict[Union[str, int], Union[Reference, Response]],
            class_name: str
    ) -> Optional[DataType]:
        """解析响应并生成对应数据模型，保持与请求体处理逻辑一致"""
        # todo：暂时只处理成功响应
        # 1. 定位成功响应（2xx状态码）
        success_code = next(
            (code for code in responses.keys() if str(code).startswith('2')),
            None
        )
        if not success_code:
            logger.debug(f"未找到成功响应状态码: {class_name}")
            return None
        response = responses[success_code]
        for content_type in SUPPORTED_CONTENT_TYPES:
            content = response.content.get(content_type)
            if not content or not content.schema_:
                logger.debug(f"响应未定义JSON Schema: {class_name}")
                continue

            # 4. 统一解析Schema（自动处理嵌套引用）
            context_name = f"{class_name}Response"

            if context_name.startswith('_'):
                context_name = context_name[1:]
                logger.debug(f"响应名称已规范化: {context_name}")

            try:
                response_type = self.parse_schema(schema_obj=content.schema_, context=context_name)
                
                if response_type.is_custom_type and response_type.type not in self.model_registry.models:
                    normalized_name = self.model_registry._normalize_name(response_type.type)
                    if normalized_name in self.model_registry.models:
                        response_type.type = normalized_name
                    else:
                        logger.error(f"未注册的自定义类型: {response_type.type}, 规范化名称: {normalized_name}")
                        raise ValueError(f"未注册的自定义类型: {response_type.type}")

                return response_type
            except Exception as e:
                logger.error(f"解析响应失败: {str(e)}")
                return DataType(
                    type="Any",
                    imports={Import(from_='typing', import_='Any')}
                )
                
        logger.debug(f"未找到支持的内容类型: {class_name}")
        return DataType(
            type="Any",
            imports={Import(from_='typing', import_='Any')}
        )

    def _parse_content_schema(
            self,
            param_name: str,
            content: Dict[str, MediaType]
    ) -> DataType:
        """解析 content 类型的参数 Schema"""
        media_type = content.get(MediaTypeEnum.JSON.value)
        if not media_type or not media_type.schema_:
            raise ValueError("仅支持 JSON 类型的 content 参数")

        return self._parse_parameter_schema(param_name, media_type.schema_)

    def _parse_parameter_schema(self, param_name: str, schema: JsonSchemaObject) -> DataType:
        """专用方法解析参数schema"""
        if self._is_basic_type(schema):
            return self._parse_basic_datatype(schema)
        model_name = f"{param_name.capitalize()}Param"

        datatype = self.parse_schema(schema, model_name)
        return datatype

    def _resolve_parameter(self, param: Union[Reference, Parameter]) -> Parameter:
        """解析参数引用"""
        if isinstance(param, Reference):
            param = self.resolver.get_ref_schema(param.ref)
        return param

    def _organize_models(self):
        """整理模型到对应的APIGroup"""
        for group in self.api_groups.values():
            group.models = {
                name: model
                for name, model in self.model_registry.models.items()
                if not model.is_inline
            }


if __name__ == '__main__':
    with open("../../api.json", 'r', encoding='utf-8') as f:
        doc = json.load(f)
    parser = OpenAPIParser(doc)
    api_groups = parser.parse()
    print(api_groups)
    print(1)
